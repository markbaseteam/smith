([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.1: [[@smith2010a]], 38-39)
- Heftiger Hunger wirkt unanständig, weil wir mit ihm nicht sympathisieren können.
- Unsere Gefährten mit gutem Appetit essen zu sehen, ist uns stattdessen angenehm. In diesem Fall harmonieren sozusagen unsere Magen miteinander.

---

- Wir können aber mit dem Leiden sympathisieren, die übermäßiger Hunger hervorruft (wenn wir ihn etwa in dem Tagebuch einer Belagerung oder einer Seereise geschildert finden). Wir versetzen uns in die Lage der Unglücklichen und sympathisieren mit all anderen Affekten, die die Erfahrung des Hungers begleiten.
- Aber insofern wir selbst nicht hungrig sind, kann man auch in diesem Fall nicht behaupten, dass wir mit ihrem Hunger sympathisieren.
