- Nach Smith gelten zwei moralische Gesetze überhaupt, deren Quelle jeweils die Religion und die Natur ist  (vgl. [[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.5.5; [[@smith2010a]], 34):
	1. das Gesetz des Christentums: „[[Nächstenliebe|unseren Nächsten zu lieben, wie wir uns selber lieben]]“;
	2. das Gebot der Natur: „uns selbst nur so zu lieben, wie wir unseren Nächsten lieben, oder was auf das Gleiche herauskommt, wie unser Nächster fähig ist, uns zu lieben“.

---

- Die Tugenden, sowohl die liebenswerten als auch die achtungsgebenden, bestehen nicht allein in den jeweiligen Vermögen (Zartgefühl und Selbstbeherrschung), sondern auch im außergewöhnlichen Grad dieser Charaktereigenschaften. ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.5.6)
