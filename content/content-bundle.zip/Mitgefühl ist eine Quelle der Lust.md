Mitgefühl ist eine Quelle der Lust

>„nichts unser Wohlgefallen mehr erweckt, als einen Menschen zu sehen, der für alle Gemütsbewegungen unserer Brust Mitgefühl empfindet“ ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.2.1; [[@smith2010a]], 13)

(„Wohlgefallen“ übersetzt hier das Englische *pleasure*).


