Sympathie verstärkt die Freude und erleichtert den Kummer

[[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.2.2; [[@smith2010a]], 14-15

>„Sie verstärkt die Freude, indem sie eine neue Quelle der Befriedigung darbietet, und sie erleichtert den Kummer, indem sie dem Herzen die einzige angenehme Empfindung einflößt, für die es in jenem Augenblick empfänglich ist.“ ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.2.2; [[@smith2010a]], 15)
