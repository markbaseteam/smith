
---
alias: ['Smith 1759, Theorie der ethischen Gefühle', 'Theorie der ethischen Gefühle', 'TMS']
---

# Smith 1759, The Theory of Moral Sentiments

- Author:: [[Smith|Adam Smith (1723-1790)]]
- Year:: 1759
- Title:: Theorie der ethischen Gefühle (engl. or. *The Theory of Moral Sentiments*)
- Subtitle:: Versuch einer Analyse der Prinzipien, mittels welcher die Menschen naturgemäß zunächst das Verhalten und den Charakter ihrer Nächsten und sodann auch ihr eigenes Verhalten und ihren eigenen Charakter beurteilen
- source:: [[@smith2010a]]
- @smith2010a = Smith, Adam. *Theorie der ethischen Gefühle*. Herausgegeben von Horst D. Brandt. Übersetzt von Walther Eckstein. Philosophische Bibliothek 605. Hamburg: Meiner, 2010. https://meiner-elibrary.de/theorie-der-ethischen-gefuhle.html.
- Markbase_site:: https://smith.markbase.xyz/Smith%201759,%20The%20Theory%20of%20Moral%20Sentiments

# Inhaltsverzeichnis

```toc
```

# Vorwort des Verfassers

Hier wird über die Änderungen berichtet, die in den späteren Auflagen vorgenommen wurden.

# Erster Teil: Über die Schicklichkeit oder sittliche Richtigkeit [*propriety*] der Handlungen

## Erster Abschnitt: Von dem Gefühl für das sittlich Richtige

### 1. Kapitel: Von der Sympathie

Zusammenfassung

- Abs. 1-5: Definition von „Mitleid“ [*compassion*] bzw. „Erbarmen“ [*pity*] und Erklärung anhand von zahlreichen Beispielen. Am Ende eine Unterscheidung der Begriffe: Erbarmen, Mitleid, Sympathie und Mitgefühl [*fellow-feeling*]
- Abs. 6-13: Man könnte glauben, dass Sympathie nur aus dem Anblick des Ausdrucks von Gefühlen anderer entstehe. Das ist nicht der Fall, denn Sympathie kann entstehen auch bloß aus dem Anblick der Situation, die den Affekt in dem Anderen auslöst. Der Anblick in seine Situation ist nur durch Einbildungskraft möglich: Wir stellen uns vor, wie es wäre, wenn wir in eine solche Situation geraten würde und wie wir darauf affektiv reagieren würden. Diese Ansicht wird durch zahlreiche Beispiele erläutert.

Zitate

![[Sympathie ist ein Prinzip der menschlichen Natur, die eine Anteilnahme an dem Gefühlszustand des Anderen ermöglicht]]

![[Phantasieren über die Situation des Anderen ist notwendige Voraussetzung, um Sympathie mit ihm zu fühlen]]

### 2. Kapitel: Von dem Wohlgefallen, welches durch gegenseitige Sympathie erzeugt wird

![[Mitgefühl ist eine Quelle der Lust]]

![[Smiths Kritik der Theorie der Selbstliebe]]

![[Sympathie verstärkt die Freude und erleichtert den Kummer]]

### 3. Kapitel:  Von der Art und Weise, wie wir über die Schicklichkeit oder Unschicklichkeit [*propriety or impropriety*] der Gemütsbewegungen anderer Menschen je nach ihrer Übereinstimmung oder Nichtübereinstimmung [*concord or dissonance*] mit unseren eigenen urteilen

![[Der Maßstab für die Beurteilung der Angemessenheit eines Affekts auf seine Ursache liegt in unserer sympathetischen Reaktion auf die fremde Gemütsbewegung]]
![[Nach Smith ist Sympathie auch als Disposition zu verstehen]]

![[Betrachtung der Empfindung, aus welcher eine Handlung hervorgeht, in Beziehung auf Ursache oder Beweggrund oder in Beziehung auf Endzweck oder Wirkung]]

![[Die Schicklichkeit oder Unschicklichkeit einer Handlung hängt von der Angemessenheit oder Unangemessenheit des Affekts ab, aus dem sie folgt]]

![[Verdienstlichkeit einer Handlung hängt von den Wirkungen ab, auf welche ihr zugrundeliegender Affekt abzielt oder sie hervorzubringen strebt]]

### 4. Kapitel:  Fortsetzung desselben Gegenstandes

![[Bildschirmfoto 2022-05-31 um 11.43.38.png]]
([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.1; [[@smith2010a]], 24)

Die Beurteilung der Schicklichkeit oder Unschicklichkeit der Gefühle eines Anderen hängt von deren Übereinstimmung mit unseren eigenen Gefühlen. Die fremden Gefühle sind schicklich, wenn sie unseren entsprechen, unschicklich, wenn dies nicht der Fall ist.

Bei der Beurteilung der fremden Gefühle kann man zwei Perspektive einnehmen: die eine Perspektive abstrahiert von der Beziehung der Gefühlsgegenstände zu mir oder der fremden Person; die andere Perspektive nimmt diese Beziehung in Betracht.

Folglich fällt das moralische Urteil darüber, ob ein fremdes Gefühl schicklich oder unschicklich ist, unterschiedlich aus.

#### 1. Übereinstimmung bei Betrachtung des Gegenstandes des Gefühls ohne Bezug auf die Beziehung, in welcher er zu uns oder zu der Person steht.

>![[Bildschirmfoto 2022-06-14 um 10.07.37.png]]
([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.2; [[@smith2010a]], 24)

Geschmack und gute Urteilsfähigkeit sind Tugenden, die wir dem Anderen zuschreiben, wenn wir seine fremden Gefühle ohne Rücksicht auf die Beziehung des Gegenstands dieser Gefühle zu uns selbst oder zu ihm betrachten und eine Übereinstimmung („Entsprechung“, „*correspondence*“ und „*harmony*“) zwischen denen und unseren Gefühlen bei demselben Gegenstand feststellen.

Beispiele:

>![[Bildschirmfoto 2022-06-14 um 10.11.01.png]]
([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.2; [[@smith2010a]], 24)

Wir sehen all diese Gegeänsde „von dem gleichen Gesichtspunkt aus“, deswegen, sagt Smith, brauchen wir keine Sympathie, d.h. den imaginativen Wechsel unserer Lage, um mit Bezug auf solche Gegenstände die Übereinstimmung mit den Gefühlen des Anderen herzustellen (vgl. [[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.2; [[@smith2010a]], 24-25).

Wenn es doch einen Unterschied unserer Gesichtspunkte gibt, hängt das von zwei verschiedenen Faktoren:

1. der unterschiedlichen Intensität unserer „Aufmerksamkeit“ (*attention*) in diesem Augenblick. Der Grad der Aufmerksamkeit kann zu verschiedenen Zeitpunkten im Leben eines Menschen variieren;
2. „*from the different degrees of natural acuteness in the faculty of the mind*“ ( [[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.2): das heißt, die Seelenvermögen variieren von Individuum zu Individuum.

Wenn ein anderer Mensch bei solchen Gegenständen, die keinen Bezug zu uns oder ihm haben, genauso wie wir fühlt, dann billigen wir diese Person. Aber er scheint weder Lob noch Bewunderung zu verdienen.

Lob und Bewunderung (*praise and admiration*) sind moralische Empfindungen, die mit einem Gefühl des Erstaunens und der Überraschung einhergehen. Der andere Mensch muss uns auf eine gewisse Art und Weise überraschen, damit wir ihn als lobensund bewundernswert ansehen können.

>![[Bildschirmfoto 2022-06-14 um 10.25.00.png]]
([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.3; [[@smith2010a]], 25)

Bewunderung beruht darauf, dass der andere Mensch unsere Aufmerksamkeit auf Dinge leiten kann, die wir sonst übersehen hätten. Ihm gehört eine gewisse Tugend des Unterscheiden, die Urteilsfähigkeit, „die allerkleinsten, kaum wahrnehmbaren Unterschiede der Schönheit und Häßlichkeit“ zu bemerken (vgl. [[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.2; [[@smith2010a]], 26). Dies gehört zu den „sogenannten intellektuellen Tugenden“ (ebd.).

Man könnte einwenden, dass wir solche Urteilsfähigkeit billigen und als Tugend anerkennen, weil sie nützlich (für uns oder für die Person selbst) ist. Smith hält aber diese These für falsch, denn die Quelle unserer Billigung solcher Charaktereigenschaft ist nicht die Nützlichkeit, sondern die Sympathie. Wir finden, dass das Urteil des Anderen den Sachen selbst angemessen ist *und* dass es mit unserem Urteil übereinstimmt.

>![[Bildschirmfoto 2022-06-14 um 10.34.41.png]]
 ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.4; [[@smith2010a]], 26)

#### 2.  Übereinstimmung bei Betrachtung des Gegenstandes des Gefühls mit Bezug auf die Beziehung, in welcher er zu uns oder zu der Person steht.

Die Übereinstimmung und Harmonie zwischen den Gefühlen zu erhalten, die sich auf einen Gegenstand beziehen, der in irgendwelcher Beziehung zu mir oder der anderen Person steht, ist schwieriger als im Fall, wo man diese Gefühle ungeachtet jener Beziehung betrachtet.

Der Grund dafür liegt grundsätzlich darin:

>![[Bildschirmfoto 2022-06-14 um 10.46.45.png]]
> ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.5; [[@smith2010a]], 27)

Ich kann über diese Diskrepanz oder diesen Mangel an Übereinstimmung zwischen unseren Gefühlen leichter hinwegsehen, wenn es sich um gleichgültige Gegenstände handelt, z.B. ein Gemälde, ein Gedicht oder sogar ein System der Philosophie (vgl. [[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.5; [[@smith2010a]], 27). Schwieriger wird es, wenn es um Gegenstände geht, durch die entweder der Andere oder ich besonders nahe berührt werden.

Aber auch wenn es schwieriger ist, ist es nichtsdestotrotz wichtiger, dass eine Übereinstimmung zwischen unseren Gefühlen in diesem Fall besteht. Denn wenn du kein Mitgefühl (*fellow-feeling*) für das Unglück hast, das *mich* betroffen hat (und nicht dich), dann:

>„so werden wir nicht mehr miteinander über diese Angelegenheiten sprechen können. Wir werden einander unerträglich werden. Ich werde deine Gesellschaft so wenig ertragen können wie du die meine.“ ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.5; [[@smith2010a]], 28)

Es entsteht demnach ein Imperativ oder eine (moralische) Vorschrift:

>![[Bildschirmfoto 2022-06-14 um 10.54.44.png]]([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.6; [[@smith2010a]], 28)

Dieses Streben nach Übereinstimmung stoßt dennoch auf eine fundamentale Grenze:

>![[Bildschirmfoto 2022-06-14 um 10.56.17.png]] ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.7; [[@smith2010a]], 28)

Die Intensität des nachempfundenen Gefühls ist anders als das Original, denn

1. jenes Gefühl „hält nur einen Augenblick an“ ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.7; [[@smith2010a]], 28), weil der Gedanke, dass ich mich gerade nicht in derselben Lage des Anderen befinde, drängt sich immer wieder auf.
2. der Grad der „Heftigkeit“ (*degree of violence*)  ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.7; [[@smith2010a]], 29) seiner und meiner Gefühle wird immer unterschiedlich sein.

Der andere wünscht sich meine Sympathie, d.h. die volle Harmonie zwischen den Gefühlen des Zuschauers und seinen eigenen.

>![[Bildschirmfoto 2022-06-14 um 11.02.08.png]]
 ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.7; [[@smith2010a]], 29)

Smith räumt aber gleichzeitig ein, dass es auch die Qualität meines sympathetischen Gefühls anders ist, denn

>![[Bildschirmfoto 2022-06-14 um 11.04.16.png]]  ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.7; [[@smith2010a]], 29)

Jedenfalls ist aber eine approximative Übereinstimmung „für die Harmonie der Gesellschaft ausreichend“ (*sufficient for the harmony of society*) ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.7; [[@smith2010a]], 29).

Aber der Mechanismus der Sympathie ist keine Einbahnstraße. So wie wir Zuschauer natürlich dazu neigen, uns in die Lage des Betroffenen zu versetzen, so neigt auch der Betroffene automatisch dazu, den Standpunkt des Zuschauers einzunehmen und seine Situation aus seinem Blickwinkel zu betrachten.

![[Bildschirmfoto 2022-06-14 um 11.09.11.png]] ![[Bildschirmfoto 2022-06-14 um 11.13.28.png]] ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.8; [[@smith2010a]], 30)

Dies bedeutet nicht, dass der Betroffene sich vorstellt, wie die Zuschauer ihn und seine Situation tatsächlich sehen. Im Gegenteil stellt sich der Betroffene in der Situation eines Zuschauers überhaupt, der seine Lage betrachtet, und stellt sich vor, was *er* (der Betroffene) fühlen würde, wenn er der Zuschauer wäre. Es ist, als ob der Betreffende sich vor einen Spiegel stellt und sich selbst betrachtet.

Dieser Mechanismus führt dazu, dass „der reflektierte Affekt“ (*the reflected passion*) „weit schwächer ist als der ursprüngliche“,

>„so dämpft jener die Heftigkeit der Gefühle, die ihn bewegten, bevor er in die Gesellschaft dieser Zuschauer kam, bevor er anfing, sich darauf zu besinnen, welchen Eindruck seine LAge auf sie machen würde, und bevor er begann, seine Lage in diesem gerechten und unparteiischen Lichte zu betrachten.“ ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.8; [[@smith2010a]], 30)

Das vorausgesetzt und weil

1. wir von einem gewöhnlichen Bekannten weniger Sympathie erwarten als von einem Freund und
2. wir noch weniger Sympathie von Seiten einer Versammlung fremder Personen erwarten als von einem gewöhnlichen Bekannten,

dann

>![[Bildschirmfoto 2022-06-14 um 11.18.23.png]] ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.9; [[@smith2010a]], 31)

Daraus folgt die Lebensweisheit:

>![[Bildschirmfoto 2022-06-14 um 11.19.54.png]] ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.4.10; [[@smith2010a]], 31)

---

### 5. Kapitel: Über die liebenswerten und die achtungsgebenden Tugenden

---

#### Unterscheidung zwischen liebenswürdigen und achtungsgebenden Tugenden

![[Smiths Unterscheidung zwischen liebenswürdigen und achtungsgebenden Tugenden]]

---

#### Grund, warum Menschen mit Mitgefühl als liebenswert erscheinen

![[Grund, warum Menschen mit Mitgefühl als liebenswert erscheinen]]

---

#### Achtung für Selbstbeherrschung

![[Selbstbeherrschung wird als Tugend geachtet]]

---

#### Vollkommenheit der menschlichen Natur

![[Vollkommenheit der menschlichen Natur als Kriterium für das moralische Urteil]]

---

#### Zwei moralische Gesetzte

![[Zwei moralische Gesetze nach Smith]]

---

#### Tugend ist eine hervorragende, ungewöhnliche Trefflichkeit

![[Tugend ist eine hervorragende, ungewöhnliche Trefflichkeit]]

---

#### Tugend und Schicklichkeit des Verhaltens unterscheiden sich voneinander

![[Tugend und Schicklichkeit des Verhaltens unterscheiden sich voneinander]]

---

#### Manchmal werden Handlungen und Eigenschaften als tugendhaft bewertet, auch wenn sie nicht vollkommen schicklich sind

![[Manchmal werden Handlungen und Eigenschaften als tugendhaft bewertet, auch wenn sie nicht vollkommen schicklich sind]]

---

## Zweiter Abschnitt: Über die Grade der verschiedenen Affekte, die mit der Schicklichkeit vereinbar sind

---

### Einleitung

---

#### Es bedarf ein Mittelmaß an der Stärke des Affekts, damit man mit ihm sympathisieren kann

![[Es bedarf ein Mittelmaß an der Stärke des Affekts, damit man mit ihm sympathisieren kann]]

---

#### Der erforderliche Mittelmaß ist verschieden bei den verschiedenen Affekten

![[Der erforderliche Mittelmaß des Affekts ist verschieden bei den verschiedenen Affekten]]

---

#### Anständigkeit oder Unanständigkeit eines Affekts hängt von deren Sympathiefähigkeit ab

![[Anständigkeit oder Unanständigkeit eines Affekts hängt von deren Sympathiefähigkeit ab]]

---

### 1. Kapitel: Über die Affekte, welche ihren Ursprung vom Körper nehmen

---

#### Wir können nur schwer mit den Affekten sympathisieren, welche ihren Ursprung vom Körper haben

![[Wir können nur schwer mit den Affekten sympathisieren, welche ihren Ursprung vom Körper haben]]

---

#### Kann man mit dem Hunger der Anderen sympathisieren?

![[Kann man mit dem Hunger der Anderen sympathisieren]]

---

#### Kann man mit der sexuellen Begierde eines Anderen sympathisieren?

![[Kann man mit der sexuellen Begierde eines Anderen sympathisieren]]

---

#### Wir missbilligen alle Begierden, die aus dem Körper entstehen, weil wir mit ihnen wenig sympathisieren können

![[Wir missbilligen alle Begierden, die aus dem Körper entstehen, weil wir mit ihnen wenig sympathisieren können]]

---

#### In der Herrschaft über die körperlichen Begierden besteht die Tugend der Mäßigkeit

![[In der Herrschaft über die körperlichen Begierden besteht die Tugend der Mäßigkeit.]]

---

#### Wir können auch mit körperlichem Schmerz der Anderen sympathisieren

![[Wir können auch mit körperlichem Schmerz der Anderen sympathisieren. Zum Beispiel]]

---

#### Wir können leichter mit Affekten aus der Einbildungskraft als aus Affekten, die aus dem Körper entspringen, sympathisieren

![[Wir können leichter mit Affekten aus der Einbildungskraft als aus Affekten, die aus dem Körper entspringen, sympathisieren]]

---

#### Wir bewundern das Ertragen körperlicher Schmerzen aufgrund des Mangels an Sympathie mit dem Betroffenen

![[Wir bewundern das Ertragen körperlicher Schmerzen aufgrund des Mangels an Sympathie mit dem Betroffenen]]

---

### 2. Kapitel: Über jene Affekte, die ihren Ursprung einer besonderen Richtung oder Beschaffenheit der Einbildungskraft verdanken

---

#### Kann man mit dem Affekt der Liebe sympathisieren?

![[Kann man mit dem Affekt der Liebe sympathisieren]]

---

#### Gebilligt wird Zurückhaltung in dem Ausdruck von Affekten, die aus der Einbildungskraft entstehen

![[Gebilligt wird Zurückhaltung in dem Ausdruck von Affekten, die aus der Einbildungskraft entstehen]]
