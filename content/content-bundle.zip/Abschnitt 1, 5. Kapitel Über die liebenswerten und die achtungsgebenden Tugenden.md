### 5. Kapitel: Über die liebenswerten und die achtungsgebenden Tugenden

---

#### Unterscheidung zwischen liebenswürdigen und achtungsgebenden Tugenden

![[Smiths Unterscheidung zwischen liebenswürdigen und achtungsgebenden Tugenden]]

---

#### Grund, warum Menschen mit Mitgefühl als liebenswert erscheinen

![[Grund, warum Menschen mit Mitgefühl als liebenswert erscheinen]]

---

#### Achtung für Selbstbeherrschung

![[Selbstbeherrschung wird als Tugend geachtet]]

---

#### Vollkommenheit der menschlichen Natur

![[Vollkommenheit der menschlichen Natur als Kriterium für das moralische Urteil]]

---

#### Zwei moralische Gesetzte

![[Zwei moralische Gesetze nach Smith]]

---

#### Tugend ist eine hervorragende, ungewöhnliche Trefflichkeit

![[Tugend ist eine hervorragende, ungewöhnliche Trefflichkeit]]

---

#### Tugend und Schicklichkeit des Verhaltens unterscheiden sich voneinander

![[Tugend und Schicklichkeit des Verhaltens unterscheiden sich voneinander]]

---

#### Manchmal werden Handlungen und Eigenschaften als tugendhaft bewertet, auch wenn sie nicht vollkommen schicklich sind

![[Manchmal werden Handlungen und Eigenschaften als tugendhaft bewertet, auch wenn sie nicht vollkommen schicklich sind]]
