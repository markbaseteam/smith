Nach Smith ist Sympathie (auch) als Disposition zu verstehen.

[[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.3.3-4; [[@smith2010a]], 20-22


> [!EXAMPLE] Beispiel
> ![[Bildschirmfoto 2022-05-24 um 11.39.55.png]]
> ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.3.3; [[@smith2010a]], 20)

> [!EXPLANATION] Erklärung
> ![[Bildschirmfoto 2022-05-24 um 11.43.47.png]]
> ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.3.3; [[@smith2010a]], 21)
