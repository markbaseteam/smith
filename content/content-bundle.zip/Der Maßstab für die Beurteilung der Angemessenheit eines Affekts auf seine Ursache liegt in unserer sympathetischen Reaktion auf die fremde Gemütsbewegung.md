Der Maßstab für die Beurteilung der Angemessenheit eines Affekts auf seine Ursache liegt in unserer sympathetischen Reaktion auf die fremde Gemütsbewegung:

>„Wenn die ursprünglichen Affekte [*passions*] desjenigen, der durch ein Ereignis in erster Linie betroffen wird, mit den sympathetischen Gemütsbewegungen des Zuschauers in voller Übereinstimmung stehen, dann werden sie notwendig diesem letzteren als richtig und schicklich [*just and proper*] und als ihren Anlässen angemessen [*suitable*] erscheinen; und umgekehrt, wenn dieser sich in den Fall hineinzudenken sucht und dabei findet, daß diese Affekte nicht mit dem übereinstimmen, was er selbst fühlt, dann erscheinen sie ihm notwendig als unrichtig und unschicklich [*unjust and improper*] und als den Ursachen unangemessen, die sie hervorrufen.“ ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.3.1; [[@smith2010a]], 18-19)

>„Wenn wir in dieser Weise über irgendeinen Affekt das Urteil fällen, er sei der Ursache [*cause*], die ihn ausgelöst hat, angemessen oder unangemessen [*proportioned or disproportioned*], dann ist es kaum möglich, daß wir uns hierzu irgendeiner anderen Richtschnur oder eines anderen Kanons bedienen als der entsprechenden Gemütsbewegung in uns selbst.“ ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.3.9; [[@smith2010a]], 23)

Die Angemessenheit oder Unangemessenheit eines Affekts kann nur in Beziehung auf seinen Gegenstand prädiziert werden. Ein Affekt ist angemessen, wenn er zu seinem Gegenstand passt.

> [!QUESTION] Frage
> Unterscheidet Smith zwischen Gegenstand und Ursache eines Affekts?
