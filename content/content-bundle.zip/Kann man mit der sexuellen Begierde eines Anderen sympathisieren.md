- Es wirkt unanständig, den „Affekt, durch den die Natur die beiden Geschlechter eint“ (sprich die sexuelle Begierde, das sexuelle Verlangen) zum Ausdruck zu bringen. 
- Denn wir können als Zuschauer nicht mit jenem Affekt sympathisieren. ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.2: [[@smith2010a]], 39)

---

- Manchmal ist aber eine Sympathie mit jenem Affekt möglich. Zum Beispiel ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.2: [[@smith2010a]], 39):
>![[Bildschirmfoto 2022-06-21 um 09.55.28.png]]


