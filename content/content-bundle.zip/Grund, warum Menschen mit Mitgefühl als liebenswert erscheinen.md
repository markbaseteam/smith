- Smith erklärt, warum Menschen, die das Vermögen des Zartgefühls (*sensitivity*) haben, uns liebenswert erscheinen. ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.5.2; [[@smith2010a]], 32)
>![[Bildschirmfoto 2022-05-31 um 10.38.32.png]]
- Dasselbe gilt umgekehrt, wenn wir merken, dass jemand nicht an dem Leid des Anderen teilnimmt, wie wir es uns erwarten würden.
