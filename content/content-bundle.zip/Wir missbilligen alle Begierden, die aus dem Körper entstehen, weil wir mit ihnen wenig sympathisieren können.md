([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.3: [[@smith2010a]], 39-40)
- Wir haben eine Abneigung gegen alle Begierden, die vom Körper ihren Ursprung nehmen. Jeder starke Ausdruck derselben wirkt ekelhaft und unangenehm. Der Grund hierfür ist, dass wir sie nicht nachfühlen können.
---
- Auch für denjenigen, der diese Begierden fühlt, hört der Gegenstand, der sie erregt, sobald sie befriedigt sind, angenehm zu sein. Er kann nämlich so wenig den Affekt, den er selbst früher erlebt hat, nachempfinden.
- Zum Beispiel ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.3: [[@smith2010a]], 40): 
>![[Bildschirmfoto 2022-06-21 um 09.58.12.png]]
