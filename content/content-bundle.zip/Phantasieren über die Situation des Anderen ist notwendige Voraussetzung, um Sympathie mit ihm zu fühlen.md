Durch Phantasie können wir uns die Situation des Anderen vorstellen und dadurch wissen, was wir fühlen würden, wenn wir in dergleichen Situation wären.

>„Da wir keine unmittelbare Erfahrung von den Gefühlen anderer Menschen besitzen, können wir uns nur so ein Bild von der Art und Weise machen, wie eine bestimmte Situation auf sie einwirken mag, daß wir uns vorzustellen suchen, was wir selbst wohl in der gleichen Situation fühlen würden.“ ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.1.2; [[@smith2010a|dt.]] 5-6)

Beispiel:

Auch wenn unser Bruder sich auf der Folterbank befindet, könnten wir nie genau empfinden, was er empfindet. „[N]ur in der Phantasie können wir uns einen Begriff von der Art seiner Empfindungen machen.“ ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.1.2; [[@smith2010a|dt.]], 6)
