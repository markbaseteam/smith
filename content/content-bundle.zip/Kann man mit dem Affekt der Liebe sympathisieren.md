- Manche Affekte, die aus der Einbildungskraft stammen, erwecken wenig Sympathie. Zum Beispiel die Liebe ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.2.1: [[@smith2010a]], 45):
>![[Bildschirmfoto 2022-06-21 um 10.35.25.png]]
---
- Liebe ist im Grunde eine private Leidenschaft. (Leidenschaften sind Affekte, die aus der Einbildungskraft stammen.) Sie erscheint jedermann, außer demjenigen, der sie fühlt, als gänzlich unverhältnismäßig gegenüber dem Wert ihres Gegenstandes. (Der Volksmund sagt, Liebe macht blind. Man sagt in Italien aber auch: Liebe ist blind.) Es ist schwer und fast unmöglich mit ihr zu sympathisieren. Und der Liebende wird auch nicht von uns verlangen, dass wir mit seinem Affekt sympathisieren und etwa gar für die gleiche Person, für die er ihn empfindet. ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.2.1: [[@smith2010a]], 44-46)
---
- Obwohl wir Liebe nicht nachempfinden können, können wir doch „die sekundären Affekte“ nachfühlen, die mit jener Leidenschaft einhergehen. (Vgl. [[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.2.2: [[@smith2010a]], 46 und [[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.2.4: [[@smith2010a]], 48). [[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.2.5: [[@smith2010a]], 48:
>![[Bildschirmfoto 2022-06-21 um 10.47.58.png]]

- Daher ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.2.2: [[@smith2010a]], 46):
>![[Bildschirmfoto 2022-06-21 um 10.43.28.png]]
---
- Moderne Trauerspielen und Romanen thematisieren die Liebe, aber was uns so stark fesselt, ist nicht die Liebe selbst, sondern eher das Leid, welches diese Liebe verursacht. [[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.2.3: [[@smith2010a]], 47:
  >![[Bildschirmfoto 2022-06-21 um 10.45.20.png]]
