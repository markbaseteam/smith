- Wir können mit Affekten, die aus der Einbildungskraft entspringen, leicht Sympathie empfinden, weil unsere Einbildungskraft lenkbarer ist und leichter Form und Gestaltung der Vorstellungen derjenigen annimmt, mit denen ich vertraut bin.
---
- Zum Beispiel ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.6: [[@smith2010a]], 41):
>![[Bildschirmfoto 2022-06-21 um 10.19.07.png]]
- Deswegen werden nicht Tragödien geschrieben, in denen es um körperliche Schmerzen geht, sondern um solche Affekte, die aus der Einbildungskraft entspringen. ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.7: [[@smith2010a]], 41-42)
---
- Körperlicher Schmerz wird rasch vergessen. Wir selbst können schwer mit unserem vergangenen Selbst sympathisieren, der Schmerz empfunden hat. Im Gegenteil erstreckt sich die Dauer der Affekte, die aus der Einbildungskraft entspringen, länger. ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.8: [[@smith2010a]], 42)
---
- Wir können mehr mit der Furcht als mit dem körperlichen Schmerz des Leidenden sympathisieren. Denn Furcht ist ein Affekt, der aus der Einbildungskraft entsteht. Gicht oder Zahnweh erregen kein starkes Mitgefühl, im Gegenteil sind gefährliche Krankheiten, auch wenn sie mit sehr wenig Schmerz verbunden sind, eine sichere Quelle des Mitleids. ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.9: [[@smith2010a]], 42)
---
- Manche Leute werden beim Anblick chirurgischer Operationen ohnmächtig und unwohl. 
- Der Hauptgrund hierfür ist aber die Neuheit dieses Anblicks, nicht weil wir so sehr mit dem Schmerz des Patienten sympathisieren. 
- Mit der Erfahrung werden wir eine Herabstimmung unserer Empfänglichkeit für solche Anblicke entwickeln.
([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.10: [[@smith2010a]], 42-43)
---
- In manchen griechischen Tragödien werden die Schmerzen des Helden ausführlich dargestellt. Wir sympathisieren jedoch mit dem Schmerz des Helden, weil wir voraussehen, dass er ihn zum Tode führen muss. Der Schmerz wird denn als Leid interpretiert und Leid ist ein Affekt, der aus der Einbildungskraft entsteht. ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.11: [[@smith2010a]], 43-44)
