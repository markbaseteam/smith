> „Es ist unanständig, einen starken Grad jener Affekte zum Ausdruck zu bringen, welche aus einem gewissen Zustand oder einer bestimmten Verfassung des Körpers entstehen; denn man kann nicht erwarten, daß unsere Umgebung, die sich nicht in der gleichen körperlichen Verfassung befindet, mit ihnen sympathisiere.“ ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.1; [[@smith2010a]], 38)

---

- Generell gilt , dass wir mit all den Affekten, die vom Körper ihren Ursprung nehmen, entweder keine Sympathie oder nur einen schwachen Grad derselben empfinden. (Vgl. [[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.5: [[@smith2010a]], 41)
