- In der Herrschaft über die körperlichen Begierden besteht die Tugend der Mäßigkeit.
- Ein Mensch ist klug, wenn er die körperlichen Begierden in jenen Grenzen hält, welche die Rücksicht auf Gesundheit und Vermögen vorschreibt. Ein Mensch ist gemäßigt, wenn er dasselbe tut, aber jetzt in Rücksicht auf Anmut, Schicklichkeit, Zartgefühl und Bescheidenheit. Im ersteren Fall ist sein Motiv individuelles Glück, im zweiten Fall das Verlangen nach moralischer Anständigkeit.

([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.4: [[@smith2010a]], 40)
