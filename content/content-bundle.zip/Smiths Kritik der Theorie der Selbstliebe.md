Smiths Kritik der Theorie der Selbstliebe

[[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.2.1; [[@smith2010a]], 13-14

Theorie der Selbstliebe:

„alle unsere Empindungen aus gewissen Verfeinerungen der Selbstliebe abzuleiten“ (wie Mandeville, Larochefcaud, Hobbes gemacht haben) ist nach Smith falsch.

Erklärung des Mitleids vonseiten der moralischen Egoistien bzw. der Vertreter der Theorie der Selbstliebe:

>„der Mensch sei sich eben seiner eigenen Schwäche und seines Bedürfnisses nach fremder Hilfe bewußt und freue sich, wenn er bemerkt, daß andere Menschen seinen Gefühlen beipflichten, weil er dann eben dieses Beistandes versichert sei; und er sei bekümmert, wenn er das Gegenteil bemerkt, weil er dann ihren Widerstand gewärtigen müsse“ ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.2.1; [[@smith2010a]], 14)

Gegenargument Smiths:

Das Mitgefühl wird so augenblicklich und oft auch bei solch geringfügigen Anlässen empfunden, dass es offenbar nicht aus einer derartigen eigennützigen Betrachtung abgeleitet werden kann.

Beispiel:

>„Jemand, der sich bemüht hat, eine Gesellschaft zu unterhalten, wird sich ungemein kränken, wenn er nachher um sich blickt und sieht, daß niemand über seine Scherze lacht als er selbst. Umgekehrt wird ihn die Heiterkeit der Gesellschaft höchst angenehm berühren und er wird diese Übereinstimmung ihrer Empfindungen mit seinen eigenen als den größten Beifall betrachten.“ ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.2.1; [[@smith2010a]], 14)
