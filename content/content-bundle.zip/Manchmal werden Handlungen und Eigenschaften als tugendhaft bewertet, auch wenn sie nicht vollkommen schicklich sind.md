- In manchen Situationen wird eine Handlung oder Eigenschaft bewundert und als tugendhaft bewertet, auch wenn sie die vollendetste Richtigkeit nicht erreicht. ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.5.8-9)
- Das liegt daran, dass der Mensch ein unvollkommenes Wesen ist und deshalb nicht immer fähig ist, seine Affekte zu beherrschen oder seine selbstische Neigung im Zaume zu halten und sich mitfühlig dem Anderen zu überlassen. ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.5.8)
---

- In Fällen dieser Art gebrauchen wir zwei verschiedene Maßstäbe ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.5.9):
	1. die Vorstellung der vollständigen Richtigkeit und Vollkommenheit (die wir aber auch wissen, dass kein Mensch dazu in der Lage ist);
	2. die Vorstellung des Grades der Nähe oder Entfernung von jener vollständigen Vollkommenheit, welchen die Handlungen der Mehrzahl der Menschen gemeinhin erreichen.
---
- Ähnlich urteilen wir in der Kunst. Der Ästhetiker beurteilt nach einer Idee der Vollkommenheit, an die aber kein Menschenwerk jemals heranreichen wird. Er mißt aber das Kunstwerk gleichzeitig an dem allgemeinen Grad von Vollendung, der gerade in dieser Kunst gewöhnlich erreicht wird. ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.5.10)
