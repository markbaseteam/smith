- Es gibt zwei verschiedene Arten von Tugend nach Smith ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.5.1; [[@smith2010a]], 32):
	1. die liebenswürdigen bzw. liebenswerten Tugenden (*amiable virtues*);
	2. die achtungsgebenden Tugenden (*respectable virtues*).

---

- Die erste Art von Tugenden beruht auf dem Vermögen des „Zartgefühls“ (*sensibility*), die zweite auf dem Vermögen der „Selbstbeherrschung“.
- Das Zartegefühl ist das Vermögen des Zuschauers, die Empfindungen des zunächst Betroffenen nachzufühlen.
- Selbstbeherrschung ist das Vermögen des Betroffenen, seine Gefühle auf jenes Maß herabzustimmen, bis zu welchem der Zuschauer mitzugehen vermag.
