Die Empfindung (*sentiment*) oder die Neigung (*affection*) des Herzes, aus welcher eine Handlung hervorgeht und von welcher laut Smith ihr (moralischer) Wert oder Unwert abhängt, kann von zwei verschiedenen Gesichtspunkten oder in zwei verschiedenen Beziehungen betrachtet werden:

1. in Beziehung auf die Ursache (*cause*), die sie hervorrief, oder den Beweggrund (*motive*), der sie veranlaßte;
2. in Beziehung auf den Endzweck (*end*), auf den sie hinzielt, oder die Wirkung (*effect*), die sie hervorzubringen strebt.

([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.i.3.5; [[@smith2010a]], 22)
