Da man nicht mit allen Affekten, die ihren Ursprung in der Einbildungskraft haben, sympathisieren kann, ist eine gewisse Zurückhaltung notwendig, wenn wir von unseren eigenen Freuden, unseren eigenen Studien und unseren eigenen Beschäftigungen sprechen. All diese sind Dinge, von denen wir nicht erwarten können, dass sie unsere Umgebung ebenso sehr interessieren. Deswegen ist ein Philosoph ein guter Gesellschafter nur für einen Philosophen.

([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.2.6: [[@smith2010a]], 49)
