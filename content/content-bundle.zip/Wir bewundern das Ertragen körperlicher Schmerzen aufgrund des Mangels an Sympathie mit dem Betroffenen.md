>„Die geringe Sympathie, die wir mit körperlichem Schmerz empfinden, ist der Grund, weshalb wir im standhaften und geduldigen Ertragen körperlicher Schmerzen das sittlich Richtige oder Schickliche erblicken.“ ([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.12: [[@smith2010a]], 44)

Wir bewundern diejenigen, die körperlichen Schmerz gut vertragen können. Bewunderung ist ein Affekt, der Billigung einerseits und Staunen und Überraschung andererseits entspringt.
