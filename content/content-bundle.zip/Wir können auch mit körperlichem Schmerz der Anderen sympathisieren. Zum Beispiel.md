>![[Bildschirmfoto 2022-06-21 um 10.13.33.png]]![[Bildschirmfoto 2022-06-21 um 10.13.43.png]]

- Mein Schmerz ist dennoch immer schwächer als der Schmerz des Betroffenen. Deswegen werde ich ihn verachten, wenn er seinen Schmerz zu stark ausdrückt, da ich seine Gefühle nicht so weit zu teilen vermag.

([[Smith 1759, The Theory of Moral Sentiments|TMS]], I.ii.1.5: [[@smith2010a]], 40-41)
